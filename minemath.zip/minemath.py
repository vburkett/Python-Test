import math
def SolveAxplusB(a,b):
    return -b/a

def SolveHypotenuse(a,b):
    return math.sqrt(a*a+b*b)